<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Migration_fix_attribute_datetime extends Migration
{
    /**
     * Perform a migration step.
     */
    public function up(): void
    {
        helper('migration');
        executeScript(APPPATH . 'Database/Migrations/sqlscripts/3.3.0_fix_attribute_datetime.sql', false, $this->db);
    }

    /**
     * Revert a migration step.
     */
    public function down(): void {}
}
